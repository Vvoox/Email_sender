# Email_sender
#This code it just for facilitate task of sending msg to many emails here its just for gmail . but you can change the host and port for other mails platformes .
If you've any problems or need some support please contact me , on Github or any other platforme ,Good luck.
Notice : Do not show your code after editing, cause will contain sensitive informations .
